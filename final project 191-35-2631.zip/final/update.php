 <?php
$servername = "localhost";
$username = "root";
$password = "";


// Create connection
$con = mysqli_connect($servername, $username, $password,"hotal");

// Check connection
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";
echo "<br>";
$id=$_GET['updateid'];
if(isset($_POST["submit"])){
$roomtype=$_POST["roomtype"];	
$bedtype=$_POST["bedtype"];	
$status=$_POST["status"];	
$price=$_POST["price"];
$sql="update `room` set id='$id',roomtype='$roomtype',bedtype='$bedtype',status='$status',price='$price'where id ='$id'";
$result=mysqli_query($con,$sql);
if($result){
 echo "data updated";
header('Location: index.php');
     exit();
}else{
	die("Connection failed: " . mysqli_connect_error());
}	
}

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="bootstrap.css">
    <title>Update</title>
  </head>
  <body>
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			<a class="navbar-brand" href="#">Room Management</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			   <span class="navbar-toggler-icon"></span>
			</button>

		  <div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
			  <li class="nav-item active">
				<a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link" href="#">Register</a>
			  </li>
			 
			  <li class="nav-item">
				<a class="nav-link disabled" href="#">Contact</a>
			  </li>
			</ul>
			
		  </div>
        </nav>
  
  
         <br>
  <br>
  <form method="post">
  <p class="h4" style="margin-left:50px;">Complete the form</p>
  <br>
  <div class="form-group w-50" style="margin-left:50px;">
    <label for="roomtype">Room Type</label>
    <input type="text" class="form-control" id="roomtype" name="roomtype" placeholder="room type">
   
  </div>
  <div class="form-group w-50" style="margin-left:50px;">
    <label for="bedtype">Bed Type</label>
    <input type="text" class="form-control" id="bedtype" name="bedtype"  placeholder="bed type">
   
  </div>
  
  <div class="form-group w-50" style="margin-left:50px;">
    <label for="status">Status</label>
    <input type="text" class="form-control" id="status" name="status" placeholder="status">
   
  </div>
  <div class="form-group w-50" style="margin-left:50px;">
    <label for="price">Price</label>
    <input type="text" class="form-control" id="price" name="price" placeholder="price">
   
  </div>
  
  
  
  <button type="submit" name="submit" class="btn btn-primary"style="margin-left:50px;" >Update</button>
</form>
		
		
  </body>
    

    
</html>
