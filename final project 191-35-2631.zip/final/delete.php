<?php
$servername = "localhost";
$username = "root";
$password = "";


// Create connection
$con = mysqli_connect($servername, $username, $password,"hotal");

// Check connection
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";
if(isset($_GET['deleteid'])){
	$id=$_GET['deleteid'];
	$sql="delete from `room` where id=$id";
	$result=mysqli_query($con,$sql);
	if($result){
		echo "deleted successfully";
		header('location:index.php');
	}else{
		die("Connection failed: " . mysqli_connect_error());
	}
}
?>