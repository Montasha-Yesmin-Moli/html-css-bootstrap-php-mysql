<?php
$servername = "localhost";
$username = "root";
$password = "";


// Create connection
$con = mysqli_connect($servername, $username, $password,"hotal");

// Check connection
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="bootstrap.css">
    <title>Home</title>
  </head>
  <body>
 
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			<a class="navbar-brand" href="#">Room Management</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			   <span class="navbar-toggler-icon"></span>
			</button>

		  <div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
			  <li class="nav-item active">
				<a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link" href="register.php">Register</a>
			  </li>
			 
			  <li class="nav-item">
				<a class="nav-link disabled" href="#">Contact</a>
			  </li>
			</ul>
			
		  </div>
        </nav>
  
  
         <table class="table table-hover">
		 <button style="margin-left:1020px;width:80px;"class="btn btn-primary"><a href="create.php"class="text-light">Add</a></button>
            <thead>
               <tr>
                   <th scope="col">Room Type</th>
                   <th scope="col">Bed Type</th>
                   <th scope="col">Status</th>
                   <th scope="col">Price</th>
                   <th scope="col">Action</th>
               </tr>
           </thead>
  <tbody>
  
  <?php
    $sql="SELECT * FROM `room`";
    $result=mysqli_query($con,$sql);
	if($result){
		while($row=mysqli_fetch_assoc( $result)){
			$id=$row['id'];
			$roomtype=$row['roomtype'];
			$bedtype=$row['bedtype'];
			$status=$row['status'];
			$price=$row['price'];
			echo '<tr>
                 <td>'.$roomtype.'</td>
                 <td>'.$bedtype.'</td>
                 <td>'.$status.'</td>
                 <td>'.$price.'</td>
                 <td>
				 <button class="btn btn-primary"><a href="update.php? updateid='.$id.'" class="text-light">Update</a></button>
				 <button class="btn btn-danger"><a href="delete.php? deleteid='.$id.'" class="text-light">Delete</a></button>
				 </td>
                 </tr>';
		}
	}
  
  ?>
  
  
   
  </tbody>
        </table>
		
		
  </body>
    

    
</html>
